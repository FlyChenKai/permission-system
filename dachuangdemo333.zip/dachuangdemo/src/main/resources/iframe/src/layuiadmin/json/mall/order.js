{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "invoice": "X123565541"
    ,"username": "张小三"
    ,"orderDate": "2017-11-10"
    ,"amount": 800
    ,"status": 1
  },{
    "invoice": "X123565542"
    ,"username": "李小四"
    ,"orderDate": "2017-11-10"
    ,"amount": 800
    ,"status": 0
  },{
    "invoice": "X123565543"
    ,"username": "王老五"
    ,"orderDate": "2017-11-10"
    ,"amount": 800
    ,"status": 1
  },{
    "invoice": "X123565544"
    ,"username": "赵小六"
    ,"orderDate": "2017-11-09"
    ,"amount": 1600
    ,"status": 1
  },{
    "invoice": "X123565545"
    ,"username": "孙小七"
    ,"orderDate": "2017-11-09"
    ,"amount": 1600
    ,"status": -1
  },{
    "invoice": "X123565546"
    ,"username": "周小八"
    ,"orderDate": "2017-11-08"
    ,"amount": 2600
    ,"status": 1
  }]
}