package com.example.dachuangdemo.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @program: youwei
 * @description:
 * @author: RedCedar
 * @create: 2018-12-28 22:50
 **/
public class ErrController implements ErrorController {
    private static final Logger logger = LoggerFactory.getLogger(ErrController.class);

    @Override
    public String getErrorPath() {
        logger.info("出错啦！进入自定义错误控制器");
        return "error";
    }

    @RequestMapping
    public String error() {
        return getErrorPath();
    }
}
