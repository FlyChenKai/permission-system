package com.example.dachuangdemo.model.dataBase;

public class Transport {
    private String housename;
    private Integer distance;
    private String point;
    private String line;

    public String getHousename() {
        return housename;
    }

    public void setHousename(String name) {
        this.housename = housename;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public Transport(String housename, Integer distance, String point, String line) {
        this.housename = housename;
        this.distance = distance;
        this.point = point;
        this.line = line;
    }
}
