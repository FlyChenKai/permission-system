package com.example.dachuangdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DachuangdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DachuangdemoApplication.class, args);
    }
}
