package com.example.dachuangdemo.model.dataBase;

public class SaleInfo {
    private String housename;
    private String lowestPay;
    private String houseType;
    private String openTime;
    private String handinTime;

    public String getHousename() {
        return housename;
    }

    public void setHousename(String housename) {
        this.housename = housename;
    }

    public String getLowestPay() {
        return lowestPay;
    }

    public void setLowestPay(String lowestPay) {
        this.lowestPay = lowestPay;
    }

    public String getHouseType() {
        return houseType;
    }

    public void setHouseType(String houseType) {
        this.houseType = houseType;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public String getHandinTime() {
        return handinTime;
    }

    public void setHandinTime(String handinTime) {
        this.handinTime = handinTime;
    }


    public SaleInfo(String housename, String lowestPay, String houseType, String openTime, String handinTime) {
        this.housename = housename;
        this.lowestPay = lowestPay;
        this.houseType = houseType;
        this.openTime = openTime;
        this.handinTime = handinTime;
    }
}
