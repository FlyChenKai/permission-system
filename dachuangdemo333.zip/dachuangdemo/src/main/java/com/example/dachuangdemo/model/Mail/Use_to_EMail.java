package com.example.dachuangdemo.model.Mail;

import com.example.dachuangdemo.model.dataBase.*;

import java.util.List;

public class Use_to_EMail {
    //第一个表
    public String use_to_email(BaseInfo baseInfo)
    {
        return "    <tr>\r\n" +
                "        <th>"+baseInfo.getHousename()+"</th>\r\n" +
                "        <th>"+baseInfo.getSaleState()+"</th>\r\n" +
                "        <th>"+baseInfo.getFeature()+"</th>\r\n" +
                "		<th>"+baseInfo.getPrice()+"</th>\r\n" +
                "        <th>"+baseInfo.getSumPrice()+"</th>\r\n" +
                "        <th>"+baseInfo.getPropertise()+"</th>\r\n" +
                "		<th>"+baseInfo.getDeveloper()+"</th>\r\n" +
                "        <th>"+baseInfo.getRegion()+"</th>\r\n" +
                "        <th>"+baseInfo.getLocation()+"</th>\r\n" +
                "    </tr>\r\n";
    }
    public String use_to_email1(List<BaseInfo> baseInfos,String[] name,int num)
    {
        String s="";
        for (BaseInfo baseInfo :
                baseInfos) {
            s+=use_to_email(baseInfo);
        }
        String x="";
        for(int i=0;i<num;i++)
            x+="        <th>"+name[i]+"</th>\r\n";
        return "    <tr>\r\n" +
                x+
                "    </tr>\r\n" +s;
    }
    //第二个表
    public String use_to_emai2(Comment comment)
    {
        return "    <tr>\r\n" +
                "        <th>"+comment.getHousename()+"</th>\r\n" +
                "        <th>"+comment.getText()+"</th>\r\n" +
                "    </tr>\r\n";
    }
    public String use_to_email21(List<Comment> comments,String[] name,int num)
    {
        String s="";
        for (Comment comment :
                comments) {
            s+=use_to_emai2(comment);
        }
        String x="";
        for(int i=0;i<num;i++)
            x+="        <th>"+name[i]+"</th>\r\n";
        return "    <tr>\r\n" +
                x+
                "    </tr>\r\n" +s;
    }
    //第三个表
    public String use_to_email3(CommunityInfo communityInfo)
    {
        return "    <tr>\r\n" +
                "        <th>"+communityInfo.getHousename()+"</th>\r\n" +
                "        <th>"+communityInfo.getBuildingType()+"</th>\r\n" +
                "        <th>"+communityInfo.getPropertyYear()+"</th>\r\n" +
                "		<th>"+communityInfo.getPlotRate()+"</th>\r\n" +
                "        <th>"+communityInfo.getGreenRate()+"</th>\r\n" +
                "        <th>"+communityInfo.getHousehold()+"</th>\r\n" +
                "		<th>"+communityInfo.getFloorCondition()+"</th>\r\n" +
                "        <th>"+communityInfo.getProjectPlan()+"</th>\r\n" +
                "        <th>"+communityInfo.getPropertyFee()+"</th>\r\n" +
                "        <th>"+communityInfo.getPropertyCompany()+"</th>\r\n" +
                "        <th>"+communityInfo.getParkNum()+"</th>\r\n" +
                "        <th>"+communityInfo.getParkProportion()+"</th>\r\n" +
                "    </tr>\r\n";
    }
    public String use_to_email31(List<CommunityInfo> communityInfos,String[] name,int num)
    {
        String s="";
        for (CommunityInfo communityInfo :
                communityInfos) {
            s+=use_to_email3(communityInfo);
        }
        String x="";
        for(int i=0;i<num;i++)
            x+="        <th>"+name[i]+"</th>\r\n";
        return "    <tr>\r\n" +
                x+
                "    </tr>\r\n" +s;
    }
    //第四个表
    public String use_to_email4(HouseDesign houseDesign)
    {
        return "    <tr>\r\n" +
                "        <th>"+houseDesign.getHousename()+"</th>\r\n" +
                "        <th>"+houseDesign.getHouseType()+"</th>\r\n" +
                "        <th>"+houseDesign.getDistribute()+"</th>\r\n" +
                "		<th>"+houseDesign.getSaleState()+"</th>\r\n" +
                "        <th>"+houseDesign.getArea()+"</th>\r\n" +
                "    </tr>\r\n";
    }
    public String use_to_email41(List<HouseDesign> houseDesigns,String[] name,int num)
    {
        String s="";
        for (HouseDesign houseDesign :
                houseDesigns) {
            s+=use_to_email4(houseDesign);
        }
        String x="";
        for(int i=0;i<num;i++)
            x+="        <th>"+name[i]+"</th>\r\n";
        return "    <tr>\r\n" +
                x+
                "    </tr>\r\n" +s;
    }
    //第五个表
    public String use_to_email5(SaleInfo saleInfo)
    {
        return "    <tr>\r\n" +
                "        <th>"+saleInfo.getHousename()+"</th>\r\n" +
                "        <th>"+saleInfo.getLowestPay()+"</th>\r\n" +
                "        <th>"+saleInfo.getHouseType()+"</th>\r\n" +
                "		<th>"+saleInfo.getOpenTime()+"</th>\r\n" +
                "        <th>"+saleInfo.getHandinTime()+"</th>\r\n" +
                "    </tr>\r\n";
    }
    public String use_to_email51(List<SaleInfo> saleInfos, String[] name, int num)
    {
        String s="";
        for (SaleInfo saleInfo :
                saleInfos) {
            s+=use_to_email5(saleInfo);
        }
        String x="";
        for(int i=0;i<num;i++)
            x+="        <th>"+name[i]+"</th>\r\n";
        return "    <tr>\r\n" +
                x+
                "    </tr>\r\n" +s;
    }
    //第六个表
    public String use_to_email6(Transport transport)
    {
        return "    <tr>\r\n" +
                "        <th>"+transport.getHousename()+"</th>\r\n" +
                "        <th>"+transport.getDistance()+"</th>\r\n" +
                "        <th>"+transport.getPoint()+"</th>\r\n" +
                "		<th>"+transport.getLine()+"</th>\r\n" +
                "    </tr>\r\n";
    }
    public String use_to_email61(List<Transport> transports, String[] name, int num)
    {
        String s="";
        for (Transport transport :
                transports) {
            s+=use_to_email6(transport);
        }
        String x="";
        for(int i=0;i<num;i++)
            x+="        <th>"+name[i]+"</th>\r\n";
        return "    <tr>\r\n" +
                x+
                "    </tr>\r\n" +s;
    }
}
