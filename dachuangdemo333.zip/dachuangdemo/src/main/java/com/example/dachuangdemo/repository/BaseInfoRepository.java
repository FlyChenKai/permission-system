package com.example.dachuangdemo.repository;

import com.example.dachuangdemo.model.dataBase.BaseInfo;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * @program: springboot-bookmanager
 * @description:
 * @author: RedCedar
 * @create: 2018-12-27 00:18
 **/


public interface BaseInfoRepository extends JpaRepository<BaseInfo, Integer> {
//    //通过楼盘名housename来查询
//    public BaseInfo findByAge(Integer id);
}
