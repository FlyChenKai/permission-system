package com.example.dachuangdemo.model.dataBase;

public class AllInfo {
    private String name;
    private double sumprice;
    private String price;
//    private String name;
//    private String name;
//    private String name;
//    private String name;
//    private String name;

}
